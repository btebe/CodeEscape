public class eg2{
 public static void main(String args[]) {

 }
}
